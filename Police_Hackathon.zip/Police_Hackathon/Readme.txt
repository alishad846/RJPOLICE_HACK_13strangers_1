Setup -

1. Copy the Folder "Police_Hackathon" into htdocs of XAMPP
2. Open phpmyadmin and goto Import Section on Status Bar
3. Import "rajasthanpolice.sql" and scroll down & press Import
4. Go to "http://localhost/police_hackathon/"

All set!!

Name - Test
Email - Test@gmail.com
Pssword - 123