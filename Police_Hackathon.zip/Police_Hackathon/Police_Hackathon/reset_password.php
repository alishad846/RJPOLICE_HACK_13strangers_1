<?php
if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET["token"])) {
    $resetToken = $_GET["token"];

    $servername = "localhost";
    $username_db = "root";
    $password_db = "";
    $dbname = "rajasthanpolice";

    $conn = new mysqli($servername, $username_db, $password_db, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $checkTableQuery = "SHOW TABLES LIKE 'signup'";
    $tableExists = $conn->query($checkTableQuery);

    if ($tableExists->num_rows == 0) {
        echo "Error: The 'signup' table does not exist.";
        $conn->close();
        exit();
    }

    $checkTokenQuery = $conn->prepare("SELECT email FROM signup WHERE reset_token = ? AND token_expiration > NOW()");
    $checkTokenQuery->bind_param("s", $resetToken);
    $checkTokenQuery->execute();
    $checkTokenQuery->store_result();

    if ($checkTokenQuery->num_rows > 0) {
        echo '<!DOCTYPE html>
                <html lang="en">
                <head>
                    <meta charset="UTF-8">
                    <title>Reset Password</title>
                    <link rel="stylesheet" href="style.css">
                </head>
                <body>
                
                <div class="background"></div>
                
                <div class="container1">
                    <h1 id="id">Welcome To Rajasthan<span class="text"></br> <span class=""></span></h1>
                </div>
                
                <div class="reset-password-form">
                    <h6>Reset Password</h6>
                    <form method="post" action="reset_password_process.php">
                        <input type="hidden" name="token" value="' . htmlspecialchars($resetToken) . '">
                        <div class="input-group">
                            <input type="password" id="newPassword" name="newPassword" placeholder="New Password" required>
                        </div>
                        <div class="input-group">
                            <input type="password" id="confirmPassword" name="confirmPassword" placeholder="Confirm Password" required>
                        </div>
                        <button type="submit">Reset Password</button>
                    </form>
                </div>
                
                </body>
                </html>';
    } else {
        echo "Invalid or expired reset token.";
    }

    $checkTokenQuery->close();
    $conn->close();
} else {
    echo "Invalid request.";
}
?>
