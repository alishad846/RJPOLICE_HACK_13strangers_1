<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $token = $_POST["token"];
    $newPassword = $_POST["newPassword"];
    $confirmPassword = $_POST["confirmPassword"];

    if ($newPassword !== $confirmPassword) {
        echo "Passwords do not match. Please try again.";
        exit();
    }

    $servername = "localhost";
    $username_db = "root";
    $password_db = "";
    $dbname = "rajasthanpolice";

    $conn = new mysqli($servername, $username_db, $password_db, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $checkTableQuery = "SHOW TABLES LIKE 'signup'";
    $tableExists = $conn->query($checkTableQuery);

    if ($tableExists->num_rows == 0) {
        echo "Error: The 'signup' table does not exist.";
        $conn->close();
        exit();
    }

    $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);

    $updatePasswordQuery = $conn->prepare("UPDATE signup SET password = ?, reset_token = NULL, token_expiration = NULL WHERE reset_token = ?");
    $updatePasswordQuery->bind_param("ss", $hashedPassword, $token);

    if ($updatePasswordQuery->execute()) {
        echo "Password reset successful. You can now log in with your new password.";
    } else {
        echo "Error updating password: " . $updatePasswordQuery->error;
    }

    $updatePasswordQuery->close();
    $conn->close();
} else {
    echo "Invalid request.";
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="refresh" content="2;url=login.php">
    <title>Redirecting...</title>
</head>
<body>
    <h1>Redirecting to login page...</h1>
    
    <button onclick="manualRedirect()">Go to Login</button>

    <script>
        function manualRedirect() {
            window.location.href = 'login.php';
        }
    </script>
</body>
</html>