<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Temp</title>
    <style>
        body {
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
            margin: 0;
            background-color: #f2f2f2;
        }

        #buttons-container {
            text-align: center;
        }

        .action-button {
            display: inline-block;
            padding: 10px 20px;
            margin: 10px;
            font-size: 16px;
            cursor: pointer;
            border: none;
            border-radius: 5px;
            color: #fff;
            background-color: #FF5539; /* Default color */
            transition: background-color 0.3s ease;
        }

        .action-button:hover {
            background-color: #BF291D; /* Color on hover */
        }

        #feedback-button {
            position: absolute;
            top: 10px;
            right: 10px;
            padding: 10px 20px;
            font-size: 16px;
            cursor: pointer;
            border: none;
            border-radius: 5px;
            color: #fff;
            background-color: #FF5539;
            transition: background-color 0.3s ease;
        }

        #feedback-button:hover {
            background-color: #BF291D;
        }

        /* Alt Footer Style */
        #alt-footer {
            position: fixed;
            bottom: 0;
            left: 0;
            width: 100%;
            background-color: #333;
            color: #fff;
            text-align: center;
            padding: 10px;
        }
    </style>
</head>
<body>
    <div id="buttons-container">
        <button class="action-button" onclick="redirectTo('signup.php')">Sign Up</button>
        <button class="action-button" onclick="redirectTo('login.php')">Login</button>
    </div>

    <button id="feedback-button" onclick="redirectTo('FeedBack-Form/index.html')">Feedback</button>

    <!-- Alt Footer -->
    <div id="alt-footer">
        Paawan Softech
    </div>

    <script>
        function redirectTo(page) {
            window.location.href = page;
        }
    </script>
</body>
</html>
