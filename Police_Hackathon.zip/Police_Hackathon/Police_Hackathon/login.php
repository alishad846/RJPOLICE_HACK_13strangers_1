<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $password = $_POST["password"];

    $servername = "localhost";
    $username_db = "root";
    $password_db = "";
    $dbname = "rajasthanpolice";

    $conn = new mysqli($servername, $username_db, $password_db, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $checkTableQuery = "SHOW TABLES LIKE 'signup'";
    $tableExists = $conn->query($checkTableQuery);

    if ($tableExists->num_rows == 0) {
        echo "Error: The 'signup' table does not exist.";
        $conn->close();
        exit();
    }

    $loginQuery = $conn->prepare("SELECT password FROM signup WHERE email = ?");
    $loginQuery->bind_param("s", $username);
    
    $loginQuery->execute();
    $loginQuery->store_result();

    if ($loginQuery->num_rows > 0) {
        $loginQuery->bind_result($hashedPassword);
        $loginQuery->fetch();

        if (password_verify($password, $hashedPassword)) {
            echo '<script>window.location.href = "main-page.html";</script>';
        } else {
            echo "Incorrect password. Please try again.";
        }
    } else {
        echo "User with email '$username' not found. Please sign up.";
    }

    $loginQuery->close();
    $conn->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Login Form</title>
  <link rel="stylesheet" href="assets/css/login-style.css">
</head>
<body>

  <div class="background"></div>

  <div class="container1">
    <h1 id="id">Welcome To Rajasthan<span class="text"></br> <span class=""></span></h1>
  </div>

  <div class="login-form">
    <h6>Login</h6>
    <form id="loginForm" method="post" action="login.php">
      <div class="input-group">
        <input type="text" name="username" id="username" placeholder="Email or Phone" required>
      </div>
      <div class="input-group">
        <input type="password" name="password" id="password" placeholder="Password" required>
        <span class="toggle-password" onclick="togglePasswordVisibility()"></span>
      </div>
      <button type="submit">Log In</button>
      <a href="forgot_password.php">Forgot Password?</a>
      <hr>
      <h3>Create a New Account</h3>
      <button class="favorite styled" type="button" onclick="redirectTo('signup.php')">Sign Up</button>
    </form>
  </div>
  <script>
        function redirectTo(page) {
            window.location.href = page;
        }
  </script>
</body>
</html>