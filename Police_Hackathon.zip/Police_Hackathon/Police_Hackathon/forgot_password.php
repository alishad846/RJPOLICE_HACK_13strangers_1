<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST["email"];

    $servername = "localhost";
    $username_db = "root";
    $password_db = "";
    $dbname = "rajasthanpolice";

    $conn = new mysqli($servername, $username_db, $password_db, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $checkTableQuery = "SHOW TABLES LIKE 'signup'";
    $tableExists = $conn->query($checkTableQuery);

    if ($tableExists->num_rows == 0) {
        echo "Error: The 'signup' table does not exist.";
        $conn->close();
        exit();
    }

    $checkUserQuery = $conn->prepare("SELECT id, fullname FROM signup WHERE email = ?");
    $checkUserQuery->bind_param("s", $email);
    $checkUserQuery->execute();
    $checkUserQuery->store_result();

    if ($checkUserQuery->num_rows > 0) {
        $resetToken = bin2hex(random_bytes(16));

        $updateTokenQuery = $conn->prepare("UPDATE signup SET reset_token = ?, token_expiration = DATE_ADD(NOW(), INTERVAL 1 HOUR) WHERE email = ?");
        $updateTokenQuery->bind_param("ss", $resetToken, $email);

        if ($updateTokenQuery->execute()) {
            header("Location: reset_password.php?token=" . urlencode($resetToken));
            exit();
        } else {
            echo "Error updating reset token: " . $updateTokenQuery->error;
        }

        $updateTokenQuery->close();
    } else {
        echo "User with email '$email' not found.";
    }

    $checkUserQuery->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Forgot Password</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="background"></div>

<div class="container1">
    <h1 id="id">Welcome To Rajasthan<span class="text"></br> <span class=""></span></h1>
</div>

<div class="forgot-password-form">
    <h6>Forgot Password</h6>
    <form method="post" action="forgot_password.php">
        <div class="input-group">
            <input type="text" id="email" name="email" placeholder="Email" required>
        </div>
        <button type="submit">Reset Password</button>
        <a href="login.html">Remember your password? Log in here.</a>
    </form>
</div>

</body>
</html>
