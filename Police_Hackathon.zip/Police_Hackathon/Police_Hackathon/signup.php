<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $fullname = $_POST["fullname"];
    $email = $_POST["email"];
    $password = password_hash($_POST["password"], PASSWORD_DEFAULT); // Hash the password for security

    // Database connection details
    $servername = "localhost";
    $username = "root";
    $password_db = "";
    $dbname = "rajasthanpolice";

    // Create connection
    $conn = new mysqli($servername, $username, $password_db, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Check if the table "signup" exists, if not, create it
    $createTableQuery = "CREATE TABLE IF NOT EXISTS signup (
                          id INT AUTO_INCREMENT PRIMARY KEY,
                          fullname VARCHAR(255) NOT NULL,
                          email VARCHAR(255) UNIQUE NOT NULL,
                          password VARCHAR(255) NOT NULL
                        )";

    if ($conn->query($createTableQuery) === FALSE) {
        echo "Error creating table: " . $conn->error;
        $conn->close();
        exit();
    }

    // Insert user data into the "signup" table using prepared statement
    $insertQuery = $conn->prepare("INSERT INTO signup (fullname, email, password) VALUES (?, ?, ?)");

    // Check for errors in the prepared statement
    if (!$insertQuery) {
        echo "Error in prepared statement: " . $conn->error;
    } else {
        // Bind parameters and execute
        $insertQuery->bind_param("sss", $fullname, $email, $password);

        // Check if bind_param is successful
        if ($insertQuery->execute()) {
            echo "User registered successfully";
        } else {
            echo "Error: " . $insertQuery->error;
        }

        // Close the prepared statement
        $insertQuery->close();
    }

    // Close connection
    $conn->close();
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Sign Up Form</title>
  <link rel="stylesheet" href="assets/css/signup-style.css">
</head>
<body>
  <div class="container">
    <div class="signup-form">
      <h2 class="signup-heading">Sign Up</h2>
      <!-- Update action and method attributes -->
      <form id="signupForm" action="signup.php" method="post">
        <!-- Your form fields go here -->
        <div class="input-group">
          <input type="text" name="fullname" placeholder="Full Name" required>
        </div>
        <div class="input-group">
          <input type="text" name="email" placeholder="Email" required>
        </div>
        <div class="input-group">
          <input type="password" name="password" placeholder="Password" required>
        </div>
        <button type="submit">Sign Up</button>
        <p>Already have an account? <a href="login.php">Sign In</a></p>
      </form>
    </div>
  </div>

  <script src="assets/js/signup-script.js"></script>
</body>
</html>
